@extends('principal')

@section('cabecalho')
<div id="m_texto">
        <img src=" {{ url('/img/relatoriop_ico.png') }}" >
        &nbsp;Relatório de Conceitos - Desempenho
</div>
@stop

@section('conteudo')

<h3> CONTEÚDO PÁGINA GERAR RELATÓRIOS </h3>

@stop
