<?php
    class aluno {

        function __construct() {
            echo "<h3> Classe: aluno -> Método: __construct() </h3>";
        }
    }

    $obj = new aluno();
?>


