<?php

    class BD {
        private $DB_NOME = "aula02";
        private $DB_USUARIO = "root";
        private $DB_SENHA = "Gil.Eduardo12";
        private $DB_CHARSET = "utf8";

        public function connection() {
            $str_conn = "mysql:host=localhost;dbname=".$this->DB_NOME;

    		return new PDO($str_conn, $this->DB_USUARIO, $this->DB_SENHA,
                array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES ".$this->DB_CHARSET));
    	}

        public function select() {
            $conn = $this->connection();
    		$stmt = $conn->prepare("SELECT * FROM tb_alunos LIMIT 3");
            $stmt->execute();

            return $stmt;
        }
    }

    $obj = new BD();
    $alunos = $obj->select();

    while($objAluno = $alunos->fetchObject()) {
        echo "<h4>".$objAluno->id." - ".$objAluno->nome."</h4>";
    }

?>
