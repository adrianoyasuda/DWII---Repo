@extends('principal')

<a href="{{ url('/') }}">Home</a>
@section('cabecalho')
    <h2>Professores Cadastrados</h2>
@stop

@section('conteudo')
<h3>Diego Hoss</h3>
<h3>Valério Brusamolin</h3>
<br>
@stop
