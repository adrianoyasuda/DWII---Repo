<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Aula05 - Laravel</title>
    </head>
    <body>
        <h1>Conceitos Iniciais / Rotas / Views/ Blade</h1>
        <div>
            @yield('cabecalho')
        </div>

        <div>
            @yield('conteudo')
        </div>

        <div>
            <b>&copy;2018 &raquo; Gil Eduardo de Andrade</b>
        </div>
    </body>
</html>
