<?php

Route::get('/', function () {
    return view("main");
});

Route::get('/alunos', 'AlunoController@listar');
Route::get('/professores', 'ProfessorController@listar');
