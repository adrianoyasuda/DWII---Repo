@extends('principal')

@section('cabecalho')
<div id="m_texto">
        <img src=" {{ url('/img/disciplinap_ico.png') }}" >
        &nbsp;Disciplinas Cadastradas
</div>
@stop

@section('conteudo')

<h3> CONTEÚDO PÁGINA DAS DISCIPLINAS </h3>

@stop
