@extends('principal')

@section('cabecalho')
<div id="m_texto">
        <img src=" {{ url('/img/cursop_ico.png') }}" >
        &nbsp;Cursos Cadastrados
</div>
@stop

@section('conteudo')

<h3> CONTEÚDO PÁGINA DOS CURSOS </h3>

@stop
