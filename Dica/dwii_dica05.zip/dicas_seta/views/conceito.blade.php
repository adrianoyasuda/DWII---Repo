@extends('principal')

@section('cabecalho')
<div id="m_texto">
        <img src=" {{ url('/img/conceitop_ico.png') }}" >
        &nbsp;Lançamento dos Conceitos
</div>
@stop

@section('conteudo')
<h3> CONTEÚDO PÁGINA LANÇAMENTO DOS CONCEITOS </h3>
@stop
