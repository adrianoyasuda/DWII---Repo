<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ImportarController extends Controller {

    public function listar() {
        return view('importar');
    }
}
