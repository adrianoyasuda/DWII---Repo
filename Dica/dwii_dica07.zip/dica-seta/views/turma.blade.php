@extends('principal')

@section('cabecalho')
<div id="m_texto">
        <img src=" {{ url('/img/turmap_ico.png') }}" >
        &nbsp;Turmas Cadastradas
</div>
@stop

@section('conteudo')

<h3> CONTEÚDO PÁGINA DAS TURMAS </h3>

@stop
