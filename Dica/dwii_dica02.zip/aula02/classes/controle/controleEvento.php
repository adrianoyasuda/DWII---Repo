<?php

    session_start();

    include_once '../../global.php';

    class controleEvento {

        public static function index() {
            echo "<script>window.location='../view/viewEvento.php'</script>";
        }

        public static function rota() {

        }
    }
