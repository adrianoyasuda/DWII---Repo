<?php

    include_once '../../global.php';

    class modeloEventoAluno extends BD {

    }
?>
