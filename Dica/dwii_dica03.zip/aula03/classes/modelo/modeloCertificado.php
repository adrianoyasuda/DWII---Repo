<?php

    include_once '../../global.php';

    class modeloCertificado extends BD {

        public static $tabela = 'tb_certificado';

    }
?>
