@extends('principal')

@section('cabecalho')
<div id="m_texto">
        <img src=" {{ url('/img/exportarp_ico.png') }}" >
        &nbsp;Exportar Dados para Outros Sistemas
</div>
@stop

@section('conteudo')

<h3> CONTEÚDO PÁGINA EXPORTAR DADOS </h3>

@stop
