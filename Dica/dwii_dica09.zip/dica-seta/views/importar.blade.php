@extends('principal')

@section('cabecalho')
<div id="m_texto">
        <img src=" {{ url('/img/importarp_ico.png') }}" >
        &nbsp;Importar Dados para o SETA
</div>
@stop

@section('conteudo')

<h3> CONTEÚDO PÁGINA IMPORTAR DADOS </h3>

@stop
