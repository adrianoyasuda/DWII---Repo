@extends('principal')

@section('cabecalho')
<div id="m_texto">
        <img src=" {{ url('/img/alunop_ico.png') }}" >
        &nbsp;Alunos Cadastrados
</div>
@stop

@section('conteudo')
<h3> CONTEÚDO PÁGINA DOS ALUNOS </h3>
@stop
