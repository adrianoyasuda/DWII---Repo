<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NivelModel extends Model {

    
}
