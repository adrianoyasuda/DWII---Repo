@extends('layout')

@section('content')
    <h1>Bem Vindo</h1>

@endsection