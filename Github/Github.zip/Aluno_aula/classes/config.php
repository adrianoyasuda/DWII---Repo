<?php

    class config {

        // Nome do DB
        const DB_NOME = 'tads17_yasuda';
        // Usuário do DB
        const DB_USUARIO = 'tads17_yasuda';
        // Senha do DB
        const DB_SENHA = '081012';
        // Charset da conexão PDO
        const DB_CHARSET = 'utf8';
		// TRUE - Apresentar erros / FALSE - Não apresentar erros
        const DEBUG = true;
    }
