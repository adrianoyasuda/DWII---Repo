@extends('principal')

<a href="{{ url('/')}}">Home</a>
@section('cabecalho')

	<h5>(Seção Blade Cabeçalho)</h5>
	<h2>Alunos Cadastrados</h2>
@stop

@section('conteudo')
	<h5>(Seção Blade Conteudo)</h5>
	<h3>Adriano Yasuda</h3>
	<h3>Tafarellll</h3>
@stop