@extends('principal')

<a href="{{ url('/')}}">Home</a>
@section('cabecalho')

	<img width="30" height="30" src="{{ url('/img/homep_ico.png') }}">
	&nbsp; <h2>Menu Principal</h2><br>
@stop

@section('conteudo')
		<a href="/alunos"><img width="150" height="150" src="{{('/img/aluno_ico.png') }}"></a>
		<a href="/professores"><img width="150" height="150" src="{{ url('/img/prof_ico.png') }}"></a>
		<br><br>
@stop