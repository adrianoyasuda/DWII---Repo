@extends('principal')

<a href="{{ url('/')}}">Home</a>
@section('cabecalho')

	<h5>(Seção Blade Cabeçalho)</h5>
	<h2>Professores Cadastrados</h2>
@stop

@section('conteudo')
	<h5>(Seção Blade Conteudo)</h5>
	<h3>Gil Eduardo</h3>
	<h3>Valério Brusamolin</h3>

@stop