<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Aula05 - Laravel</title>
	</head>

	<body>
		<h1>Conceitos Iniciais / Rotas / Views/ Blade</h1>

		<div>
			<?php echo $__env->yieldContent('cabecalho'); ?>
		</div>

		<div>
			<?php echo $__env->yieldContent('conteudo'); ?>
		</div>

		<div>
			<b>&copy; 2019 &raquo; Adriano Yasuda</b>
		</div>
	</body>
</html><?php /**PATH G:\2019\Web II - Gil\Pasta para Prova\Github\AulasLaravel\Aula05\resources\views/principal.blade.php ENDPATH**/ ?>