<a href="<?php echo e(url('/')); ?>">Home</a>
<?php $__env->startSection('cabecalho'); ?>

	<h5>(Seção Blade Cabeçalho)</h5>
	<h2>Alunos Cadastrados</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
	<h5>(Seção Blade Conteudo)</h5>
	<h3>Adriano Yasuda</h3>
	<h3>Tafarellll</h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\2019\Web II - Gil\Pasta para Prova\Github\AulasLaravel\Aula05\resources\views/alunos.blade.php ENDPATH**/ ?>