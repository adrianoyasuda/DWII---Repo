<a href="<?php echo e(url('/')); ?>">Home</a>
<?php $__env->startSection('cabecalho'); ?>

	<img width="30" height="30" src="<?php echo e(url('/img/homep_ico.png')); ?>">
	&nbsp; <h2>Menu Principal</h2><br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
		<a href="/alunos"><img width="150" height="150" src="<?php echo e(('/img/aluno_ico.png')); ?>"></a>
		<a href="/professores"><img width="150" height="150" src="<?php echo e(url('/img/prof_ico.png')); ?>"></a>
		<br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\2019\Web II - Gil\Pasta para Prova\Github\AulasLaravel\Aula05\resources\views/main.blade.php ENDPATH**/ ?>