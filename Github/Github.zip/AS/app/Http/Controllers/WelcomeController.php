<?php

namespace App\Http\Controllers;

use Request;

class WelcomeController extends Controller{

    public function resultado(){

		$nomes = array();

    	for ($i=1; $i <= 8 ; $i++) { 
    		$nomes[$i] = Request::input('nome_'.$i.'');
    	}
    	

        return view('resultado')->with('nomes', $nomes);
    }
}
