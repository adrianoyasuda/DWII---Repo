@extends('principal')

@section('cabecalho')
    <div class="container" id="m_texto">
        <div style="text-align: center;">
            <img src=" {{ url('/img/secret.png') }}" width="200" height="200" alt="0">
        </div>

        <div style="text-align: center;">&nbsp;Resultado</div>
    </div>
@stop

@section('conteudo')

	<div class='container'> 
    	<div class="container" style="text-align: center;">
        	<h4>{{$nomes[random_int(1,8)]}}<------->{{$nomes[random_int(1,8)]}}</h4>
        	<h4>{{$nomes[random_int(1,8)]}}<------->{{$nomes[random_int(1,8)]}}</h4>
        	<h4>{{$nomes[random_int(1,8)]}}<------->{{$nomes[random_int(1,8)]}}</h4>
        	<h4>{{$nomes[random_int(1,8)]}}<------->{{$nomes[random_int(1,8)]}}</h4>
    	</div>
    </div>

@stop
