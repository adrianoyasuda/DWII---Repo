<!DOCTYPE html>
<head>
    <title>Gerador Amigo Secreto</title>

    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

    <!--Custom css-->
    <link href="{{ url('/themes/theme.css') }}" rel="stylesheet">

    {{--	<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>--}}
    {{--    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>--}}
    @yield('script')
</head>



<div class="container theme-showcase" role="main">

    <div class="page-header">

        <div class="page-header">
            <h1 class="form-signin-heading">
                @yield('cabecalho')
            </h1>
        </div>

        @yield('conteudo')

    </div>

    <div class="page-header">
        <b>&copy;2019
            &nbsp;&nbsp;&raquo;&nbsp;&nbsp;
            Adriano Yasuda
            &nbsp;&nbsp;&raquo;&nbsp;&nbsp;
            versão 1.0
        </b>
    </div>
</div>
