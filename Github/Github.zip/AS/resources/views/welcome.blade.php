@extends('principal')

@section('cabecalho')
    <div id="m_texto">
            <div style="text-align: center;">
                <img src=" {{ url('/img/secret.png') }}" width="200" height="200" alt="0">
            </div>

            <div style="text-align: center;">&nbsp;Gerador - Amigo Secreto</div>
    </div>
@stop

@section('conteudo')

    <form action="{{action('WelcomeController@resultado')}}" method="POST" >
        <div class="row">
            <input type="hidden" name="_token" value="{{{csrf_token()}}}">

            
                @for ($i = 1; $i <= 8; $i++) 

                    <div class="col-sm-6" style="margin-bottom: 8px">
                        <input placeholder="Nome" type="text" name="nome_{{$i}}" class="form-control">
                    </div>
                @endfor
            
            <button type="submit" class="btn btn-success btn-block">Gerar Resultado</button>
        </div>
    </form>
@stop
