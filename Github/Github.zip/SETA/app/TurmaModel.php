<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TurmaModel extends Model {
    
}
