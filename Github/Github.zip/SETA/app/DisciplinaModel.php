<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DisciplinaModel extends Model {
    
    //
}
